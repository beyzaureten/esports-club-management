package com.esportsclub.model;

public class User {

    private int id;
    private String username;
    private String password;
    private String email;
    private String role; // "ADMIN" veya "MEMBER"
    private String status; // "ACTIVE" veya "INACTIVE"

    // Constructor - boş
    public User() {}

    // Constructor - parametreli
    public User(int id, String username, String password, String email, String role, String status) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.email = email;
        this.role = role;
        this.status = status;
    }

    // Getters
    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getPassword() { return password; }
    public String getEmail() { return email; }
    public String getRole() { return role; }
    public String getStatus() { return status; }

    // Setters
    public void setId(int id) { this.id = id; }
    public void setUsername(String username) { this.username = username; }
    public void setPassword(String password) { this.password = password; }
    public void setEmail(String email) { this.email = email; }
    public void setRole(String role) { this.role = role; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "User{id=" + id + ", username='" + username + "', role='" + role + "'}";
    }
}