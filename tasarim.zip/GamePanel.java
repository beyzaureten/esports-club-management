package com.esportsclub.ui;

import com.esportsclub.model.Game;
import com.esportsclub.service.GameService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.List;

/**
 * GamePanel — Oyun yönetimi (CRUD) ekranı.
 *
 * Özellikler:
 *   - Canlı arama: isim, genre, mod alanlarında anlık RowFilter
 *   - Genre dropdown filtresi (veritabanından dinamik doldurulur)
 *   - Sütun sıralama (tablo başlığına tıklama)
 *   - Satır seçimi → form alanları otomatik doldurulur
 *   - "Teams Using" sütunu: oyunu oynayan takım sayısı
 *   - Silme: bağlı takım varsa anlamlı hata mesajı verilir
 *   - Kayıt sayacı: "Showing X of Y records"
 *   - Form temizleme butonu
 */
public class GamePanel extends JPanel {

    // ---- Renkler ----
    private static final Color PRIMARY    = new Color(30, 80, 170);
    private static final Color BTN_ADD    = new Color(34, 130, 60);
    private static final Color BTN_UPD    = new Color(30, 80, 170);
    private static final Color BTN_DEL    = new Color(185, 40, 40);
    private static final Color BTN_CLR    = new Color(100, 105, 120);

    private final GameService gameService = new GameService();

    // ---- Tablo ----
    private JTable               table;
    private DefaultTableModel    model;
    private TableRowSorter<DefaultTableModel> sorter;

    // ---- Filtre ----
    private JTextField    fldSearch;
    private JComboBox<String> cmbGenre;

    // ---- Form ----
    private JTextField fldId, fldName, fldGenre, fldMode;

    // ---- Butonlar ----
    private JButton btnAdd, btnUpdate, btnDelete, btnClear;
    private JLabel  lblCount;

    // =========================================================================
    public GamePanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(new Color(240, 242, 248));
        add(buildToolbar(),  BorderLayout.NORTH);
        add(buildTable(),    BorderLayout.CENTER);
        add(buildForm(),     BorderLayout.SOUTH);
        loadAll();
    }

    // =========================================================================
    // Toolbar (başlık + arama + filtre)
    // =========================================================================
    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBackground(new Color(240, 242, 248));
        bar.setBorder(new EmptyBorder(10, 14, 8, 14));

        JLabel title = new JLabel("Game Management");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(PRIMARY);
        bar.add(title, BorderLayout.WEST);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        filters.setOpaque(false);

        filters.add(smallLabel("Search:"));
        fldSearch = new JTextField(16);
        fldSearch.setFont(new Font("Arial", Font.PLAIN, 12));
        fldSearch.setToolTipText("Filter by name, genre or mode");
        fldSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applyFilter(); }
            public void removeUpdate(DocumentEvent e) { applyFilter(); }
            public void changedUpdate(DocumentEvent e) {}
        });
        filters.add(fldSearch);

        filters.add(smallLabel("Genre:"));
        cmbGenre = new JComboBox<>();
        cmbGenre.setFont(new Font("Arial", Font.PLAIN, 12));
        cmbGenre.setPreferredSize(new Dimension(120, 26));
        cmbGenre.addActionListener(e -> applyFilter());
        filters.add(cmbGenre);

        JButton btnRefresh = smallBtn("Refresh", new Color(90, 95, 110));
        btnRefresh.addActionListener(e -> loadAll());
        filters.add(btnRefresh);

        bar.add(filters, BorderLayout.EAST);
        return bar;
    }

    // =========================================================================
    // Tablo
    // =========================================================================
    private JScrollPane buildTable() {
        String[] cols = {"ID", "Game Name", "Genre", "Mode", "Teams Using"};
        model = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return (c == 0 || c == 4) ? Integer.class : String.class;
            }
        };

        table = new JTable(model);
        table.setFont(new Font("Arial", Font.PLAIN, 13));
        table.setRowHeight(27);
        table.setGridColor(new Color(218, 220, 232));
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);
        table.setSelectionBackground(new Color(195, 215, 255));
        table.setSelectionForeground(Color.BLACK);
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        table.getTableHeader().setBackground(new Color(230, 235, 250));
        table.getTableHeader().setReorderingAllowed(false);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        // Sütun genişlikleri
        int[] widths = {55, 230, 130, 110, 105};
        for (int i = 0; i < widths.length; i++)
            table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

        // Ortalanmış sütunlar
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        for (int c : new int[]{0, 4}) table.getColumnModel().getColumn(c).setCellRenderer(center);

        // Sıralama
        sorter = new TableRowSorter<>(model);
        table.setRowSorter(sorter);

        // Satır seçimi → form doldur
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) fillForm();
        });

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createMatteBorder(1, 0, 1, 0, new Color(205, 210, 225)));
        return sp;
    }

    // =========================================================================
    // Form
    // =========================================================================
    private JPanel buildForm() {
        JPanel wrap = new JPanel(new BorderLayout(0, 0));
        wrap.setBackground(new Color(247, 248, 252));
        wrap.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(205, 210, 225)));

        // ---- Grid form ----
        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(10, 14, 6, 14));
        GridBagConstraints g = new GridBagConstraints();
        g.fill    = GridBagConstraints.HORIZONTAL;
        g.insets  = new Insets(4, 6, 4, 6);
        g.gridy   = 0;

        // Satır 1: ID | Name
        g.gridx = 0; g.weightx = 0.06; form.add(formLbl("ID"),          g);
        g.gridx = 1; g.weightx = 0.12;
        fldId = new JTextField(); fldId.setEditable(false);
        fldId.setBackground(new Color(228, 230, 240));
        fldId.setFont(new Font("Arial", Font.PLAIN, 12));
        form.add(fldId, g);
        g.gridx = 2; g.weightx = 0.1; form.add(formLbl("Game Name *"), g);
        g.gridx = 3; g.weightx = 0.35; fldName = formField("e.g. Valorant"); form.add(fldName, g);

        // Satır 2: Genre | Mode
        g.gridy = 1;
        g.gridx = 0; g.weightx = 0.06; form.add(formLbl("Genre *"), g);
        g.gridx = 1; g.weightx = 0.12; fldGenre = formField("e.g. FPS, MOBA, BR"); form.add(fldGenre, g);
        g.gridx = 2; g.weightx = 0.1;  form.add(formLbl("Mode *"),  g);
        g.gridx = 3; g.weightx = 0.35; fldMode = formField("e.g. 5v5, 1v1, Solo"); form.add(fldMode, g);

        wrap.add(form, BorderLayout.CENTER);

        // ---- Butonlar ----
        JPanel btnRow = new JPanel(new BorderLayout(0, 0));
        btnRow.setOpaque(false);
        btnRow.setBorder(new EmptyBorder(0, 14, 10, 14));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);

        btnAdd    = actionBtn("Add Game",   BTN_ADD, 110);
        btnUpdate = actionBtn("Update",     BTN_UPD, 100);
        btnDelete = actionBtn("Delete",     BTN_DEL, 100);
        btnClear  = actionBtn("Clear Form", BTN_CLR, 100);

        btnAdd.addActionListener(e    -> doAdd());
        btnUpdate.addActionListener(e -> doUpdate());
        btnDelete.addActionListener(e -> doDelete());
        btnClear.addActionListener(e  -> clearForm());

        left.add(btnAdd); left.add(btnUpdate); left.add(btnDelete); left.add(btnClear);

        lblCount = new JLabel();
        lblCount.setFont(new Font("Arial", Font.ITALIC, 11));
        lblCount.setForeground(new Color(115, 120, 140));

        btnRow.add(left,     BorderLayout.WEST);
        btnRow.add(lblCount, BorderLayout.EAST);
        wrap.add(btnRow, BorderLayout.SOUTH);

        return wrap;
    }

    // =========================================================================
    // İş Mantığı
    // =========================================================================
    private void doAdd() {
        String name  = fldName.getText().trim();
        String genre = fldGenre.getText().trim();
        String mode  = fldMode.getText().trim();
        if (name.isEmpty() || genre.isEmpty() || mode.isEmpty()) {
            warn("Please fill in all required fields (marked with *)."); return;
        }
        if (gameService.addGame(name, genre, mode)) {
            info("Game \"" + name + "\" added successfully.");
            clearForm(); loadAll();
        } else {
            error("Failed to add game. A game with this name may already exist.");
        }
    }

    private void doUpdate() {
        if (fldId.getText().trim().isEmpty()) { warn("Select a game from the table first."); return; }
        String name  = fldName.getText().trim();
        String genre = fldGenre.getText().trim();
        String mode  = fldMode.getText().trim();
        if (name.isEmpty() || genre.isEmpty() || mode.isEmpty()) {
            warn("Please fill in all required fields (marked with *)."); return;
        }
        try {
            Game g = new Game(Integer.parseInt(fldId.getText().trim()), name, genre, mode);
            if (gameService.updateGame(g)) {
                info("Game updated successfully.");
                clearForm(); loadAll();
            } else {
                error("Update failed. Another game with this name may already exist.");
            }
        } catch (NumberFormatException ex) { error("Invalid ID."); }
    }

    private void doDelete() {
        if (fldId.getText().trim().isEmpty()) { warn("Select a game from the table first."); return; }
        String gameName = fldName.getText().trim();
        int confirm = JOptionPane.showConfirmDialog(this,
                "Delete game \"" + gameName + "\"?\nThis action cannot be undone.",
                "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
        if (confirm != JOptionPane.YES_OPTION) return;

        try {
            String err = gameService.deleteGame(Integer.parseInt(fldId.getText().trim()));
            if (err == null) { info("Game deleted."); clearForm(); loadAll(); }
            else             { error(err); }
        } catch (NumberFormatException ex) { error("Invalid ID."); }
    }

    // =========================================================================
    // Veri yükleme / filtreleme
    // =========================================================================
    private void loadAll() {
        model.setRowCount(0);
        List<Game> games = gameService.getAllGames();
        for (Game g : games) {
            int teams = gameService.getTeamCountForGame(g.getId());
            model.addRow(new Object[]{g.getId(), g.getName(), g.getGenre(), g.getMode(), teams});
        }
        refreshGenreCombo(games);
        updateCount();
    }

    private void applyFilter() {
        String kw     = fldSearch.getText().trim();
        Object genSel = cmbGenre.getSelectedItem();
        String genre  = (genSel == null || "All Genres".equals(genSel)) ? "" : genSel.toString();

        RowFilter<DefaultTableModel, Object> f = RowFilter.andFilter(Arrays.asList(
                kw.isEmpty()    ? RowFilter.regexFilter(".*")
                               : RowFilter.regexFilter("(?i)" + kw, 1, 2, 3),
                genre.isEmpty() ? RowFilter.regexFilter(".*")
                               : RowFilter.regexFilter("(?i)^" + genre + "$", 2)
        ));
        sorter.setRowFilter(f);
        updateCount();
    }

    private void refreshGenreCombo(List<Game> games) {
        Object cur = cmbGenre.getSelectedItem();
        cmbGenre.removeAllItems();
        cmbGenre.addItem("All Genres");
        games.stream().map(Game::getGenre).distinct().sorted().forEach(cmbGenre::addItem);
        if (cur != null) cmbGenre.setSelectedItem(cur);
    }

    private void fillForm() {
        int row = table.getSelectedRow();
        if (row < 0) return;
        int mr = table.convertRowIndexToModel(row);
        fldId.setText(model.getValueAt(mr, 0).toString());
        fldName.setText(model.getValueAt(mr, 1).toString());
        fldGenre.setText(model.getValueAt(mr, 2).toString());
        fldMode.setText(model.getValueAt(mr, 3).toString());
    }

    private void clearForm() {
        fldId.setText(""); fldName.setText(""); fldGenre.setText(""); fldMode.setText("");
        table.clearSelection();
        fldName.requestFocus();
    }

    private void updateCount() {
        lblCount.setText("Showing " + table.getRowCount() + " of " + model.getRowCount() + " records   ");
    }

    // =========================================================================
    // UI helpers
    // =========================================================================
    private JLabel formLbl(String t) {
        JLabel l = new JLabel(t); l.setFont(new Font("Arial", Font.BOLD, 12));
        l.setForeground(new Color(55, 60, 80)); return l;
    }

    private JLabel smallLabel(String t) {
        JLabel l = new JLabel(t); l.setFont(new Font("Arial", Font.PLAIN, 12)); return l;
    }

    private JTextField formField(String tip) {
        JTextField f = new JTextField();
        f.setFont(new Font("Arial", Font.PLAIN, 12));
        f.setToolTipText(tip);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(185, 192, 215)),
                BorderFactory.createEmptyBorder(3, 7, 3, 7)));
        return f;
    }

    private JButton actionBtn(String text, Color bg, int width) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 12));
        b.setBackground(bg); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(width, 30));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }

    private JButton smallBtn(String text, Color bg) { return actionBtn(text, bg, 80); }

    private void info(String m)  { JOptionPane.showMessageDialog(this, m, "Success", JOptionPane.INFORMATION_MESSAGE); }
    private void warn(String m)  { JOptionPane.showMessageDialog(this, m, "Warning", JOptionPane.WARNING_MESSAGE); }
    private void error(String m) { JOptionPane.showMessageDialog(this, m, "Error",   JOptionPane.ERROR_MESSAGE); }
}
