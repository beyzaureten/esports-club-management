package com.esportsclub.service;

import com.esportsclub.dao.GameDAO;
import com.esportsclub.dao.TeamDAO;
import com.esportsclub.model.Game;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * GameService — Oyun yönetimi iş mantığı (Service Layer).
 *
 * DAO katmanının üzerinde şu sorumlulukları üstlenir:
 *   1. Alan validasyonu (boş, uzunluk sınırları)
 *   2. İş kuralları:
 *      - Silme öncesi bağlı takım kontrolü (cascade delete önleme)
 *      - Aynı isimle iki oyun eklenemez (case-insensitive)
 *   3. Filtreleme ve arama (isim, genre, mod — Stream API)
 *   4. İstatistik yardımcıları (genre listesi, takım sayısı)
 *
 * Hata durumlarında false / null döndürür ve detayı loglar.
 * Üst katman (UI) Optional veya dönüş değerini kontrol etmelidir.
 */
public class GameService {

    private final GameDAO gameDAO;
    private final TeamDAO teamDAO;

    public GameService() {
        this.gameDAO = new GameDAO();
        this.teamDAO = new TeamDAO();
    }

    // =========================================================================
    // CRUD
    // =========================================================================

    /**
     * Yeni oyun ekler.
     *
     * @param name  oyun adı (boş olamaz, max 100 karakter)
     * @param genre tür (boş olamaz, max 50 karakter)
     * @param mode  oyun modu (boş olamaz, max 20 karakter)
     * @return true — başarıyla eklendi; false — validasyon veya duplicate hatası
     */
    public boolean addGame(String name, String genre, String mode) {
        String err = validate(name, genre, mode);
        if (err != null) { log("addGame", err); return false; }

        if (isDuplicateName(name, -1)) {
            log("addGame", "A game named '" + name.trim() + "' already exists.");
            return false;
        }
        gameDAO.insert(new Game(0, name.trim(), genre.trim(), mode.trim()));
        return true;
    }

    /**
     * Mevcut bir oyunu günceller.
     *
     * @param game güncellenmiş Game nesnesi (id set edilmiş olmalı)
     * @return true — başarıyla güncellendi; false — validasyon hatası
     */
    public boolean updateGame(Game game) {
        if (game == null) { log("updateGame", "game object is null"); return false; }
        String err = validate(game.getName(), game.getGenre(), game.getMode());
        if (err != null) { log("updateGame", err); return false; }

        if (isDuplicateName(game.getName(), game.getId())) {
            log("updateGame", "Another game with name '" + game.getName().trim() + "' already exists.");
            return false;
        }
        gameDAO.update(game);
        return true;
    }

    /**
     * Oyunu siler.
     * Bu oyuna bağlı en az bir takım varsa silmeyi reddeder.
     *
     * @param id silinecek oyunun ID'si
     * @return null — silme başarılı; hata mesajı — silme reddedildi
     */
    public String deleteGame(int id) {
        int teamCount = teamDAO.getByGameId(id).size();
        if (teamCount > 0) {
            return "Cannot delete: " + teamCount + " team(s) are linked to this game. "
                    + "Remove or reassign the teams first.";
        }
        gameDAO.delete(id);
        return null; // null → başarılı
    }

    // =========================================================================
    // Sorgular
    // =========================================================================

    public Optional<Game> getGameById(int id) {
        return Optional.ofNullable(gameDAO.getById(id));
    }

    public List<Game> getAllGames() {
        return gameDAO.getAll();
    }

    /**
     * İsim, genre veya mod alanlarında anahtar kelime arar (case-insensitive).
     * Boş keyword → tüm oyunlar döner.
     */
    public List<Game> search(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) return getAllGames();
        String kw = keyword.trim().toLowerCase();
        return gameDAO.getAll().stream()
                .filter(g -> g.getName().toLowerCase().contains(kw)
                          || g.getGenre().toLowerCase().contains(kw)
                          || g.getMode().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }

    /**
     * Belirli bir genre'ya ait oyunları döndürür (case-insensitive).
     * "All" veya boş → tüm oyunlar.
     */
    public List<Game> getByGenre(String genre) {
        if (genre == null || genre.trim().isEmpty() || "All".equalsIgnoreCase(genre))
            return getAllGames();
        return gameDAO.getAll().stream()
                .filter(g -> g.getGenre().equalsIgnoreCase(genre.trim()))
                .collect(Collectors.toList());
    }

    /**
     * Tüm benzersiz genre değerlerini alfabetik sırada döndürür.
     * UI filtre dropdown'ı için kullanılır.
     */
    public List<String> getAllGenres() {
        return gameDAO.getAll().stream()
                .map(Game::getGenre)
                .map(String::trim)
                .distinct()
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .collect(Collectors.toList());
    }

    /**
     * Verilen oyunu oynayan takım sayısını döndürür.
     * GamePanel'deki "Teams Using" sütunu için kullanılır.
     */
    public int getTeamCountForGame(int gameId) {
        return teamDAO.getByGameId(gameId).size();
    }

    // =========================================================================
    // Validasyon
    // =========================================================================

    private String validate(String name, String genre, String mode) {
        if (name  == null || name.trim().isEmpty())  return "Game name cannot be empty.";
        if (genre == null || genre.trim().isEmpty()) return "Genre cannot be empty.";
        if (mode  == null || mode.trim().isEmpty())  return "Mode cannot be empty.";
        if (name.trim().length()  > 100) return "Game name cannot exceed 100 characters.";
        if (genre.trim().length() > 50)  return "Genre cannot exceed 50 characters.";
        if (mode.trim().length()  > 20)  return "Mode cannot exceed 20 characters.";
        return null;
    }

    /**
     * @param excludeId  güncelleme sırasında kendi ID'sini hariç tut; yeni ekleme için -1
     */
    private boolean isDuplicateName(String name, int excludeId) {
        return gameDAO.getAll().stream()
                .anyMatch(g -> g.getName().trim().equalsIgnoreCase(name.trim())
                            && g.getId() != excludeId);
    }

    private void log(String method, String msg) {
        System.out.println("[GameService." + method + "] " + msg);
    }
}
