package com.esportsclub.ui;

import com.esportsclub.model.User;
import com.esportsclub.service.UserService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;

/**
 * LoginPanel — Kullanıcı giriş ve kayıt ekranı.
 *
 * Özellikler:
 *   - Login / Register sekme yapısı (JTabbedPane)
 *   - SwingWorker ile asenkron login (UI donmaz)
 *   - Şifre göster/gizle toggle butonu
 *   - Enter tuşu → login tetiklenir
 *   - Alan validasyonu: boş alan, min uzunluk, email format, şifre eşleşme
 *   - Başarılı login → MainFrame.onLoginSuccess(User) çağrısı
 *   - INACTIVE hesap girişi engellenir
 */
public class LoginPanel extends JPanel {

    private static final Color PRIMARY  = new Color(30, 80, 170);
    private static final Color SUCCESS  = new Color(34, 130, 60);
    private static final Color ERROR_C  = new Color(190, 40, 40);

    private final MainFrame   mainFrame;
    private final UserService userService;

    // ---- Login bileşenleri ----
    private JTextField     fldLoginUser;
    private JPasswordField fldLoginPass;
    private JButton        btnLogin;
    private JLabel         lblLoginMsg;

    // ---- Register bileşenleri ----
    private JTextField     fldRegUser;
    private JTextField     fldRegEmail;
    private JPasswordField fldRegPass;
    private JPasswordField fldRegConfirm;
    private JLabel         lblRegMsg;

    // =========================================================================
    public LoginPanel(MainFrame mainFrame) {
        this.mainFrame   = mainFrame;
        this.userService = new UserService();
        setLayout(new GridBagLayout());
        setBackground(new Color(230, 234, 245));
        buildUI();
    }

    // =========================================================================
    // UI
    // =========================================================================
    private void buildUI() {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setPreferredSize(new Dimension(460, 540));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 210, 230), 1),
                BorderFactory.createEmptyBorder(0, 0, 24, 0)
        ));

        card.add(buildCardHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane(JTabbedPane.TOP);
        tabs.setFont(new Font("Arial", Font.PLAIN, 13));
        tabs.setBorder(new EmptyBorder(8, 10, 0, 10));
        tabs.addTab("  Login  ",    buildLoginTab());
        tabs.addTab("  Register  ", buildRegisterTab());
        card.add(tabs, BorderLayout.CENTER);

        add(card);
    }

    // ---- Kart başlığı ----
    private JPanel buildCardHeader() {
        JPanel header = new JPanel(new GridLayout(2, 1, 0, 6));
        header.setBackground(PRIMARY);
        header.setBorder(new EmptyBorder(22, 24, 22, 24));

        JLabel title = new JLabel("E-Sports Club Management", SwingConstants.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 19));
        title.setForeground(Color.WHITE);

        JLabel sub = new JLabel("MISY1102  ·  Spring 2026", SwingConstants.CENTER);
        sub.setFont(new Font("Arial", Font.PLAIN, 12));
        sub.setForeground(new Color(180, 210, 255));

        header.add(title);
        header.add(sub);
        return header;
    }

    // ---- Login sekmesi ----
    private JPanel buildLoginTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(22, 36, 12, 36));
        GridBagConstraints g = gbc();

        g.gridy = 0; p.add(lbl("Username"), g);
        g.gridy = 1; fldLoginUser = textField(); p.add(fldLoginUser, g);

        g.gridy = 2; g.insets = ins(14, 0, 4, 0); p.add(lbl("Password"), g);
        g.gridy = 3; g.insets = ins(0, 0, 0, 0);
        p.add(passwordRow(fldLoginPass = pwField()), g);

        g.gridy = 4; g.insets = ins(5, 0, 0, 0);
        lblLoginMsg = msgLabel();
        p.add(lblLoginMsg, g);

        g.gridy = 5; g.insets = ins(18, 0, 0, 0);
        btnLogin = primaryBtn("Login", PRIMARY);
        btnLogin.addActionListener(e -> doLogin());
        p.add(btnLogin, g);

        g.gridy = 6; g.insets = ins(14, 0, 0, 0);
        JLabel hint = new JLabel("Demo: admin / admin123", SwingConstants.CENTER);
        hint.setFont(new Font("Arial", Font.ITALIC, 11));
        hint.setForeground(new Color(160, 165, 180));
        p.add(hint, g);

        // Enter tuşu
        ActionListener doLogin = e -> doLogin();
        fldLoginUser.addActionListener(doLogin);
        fldLoginPass.addActionListener(doLogin);

        return p;
    }

    // ---- Register sekmesi ----
    private JPanel buildRegisterTab() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new EmptyBorder(18, 36, 12, 36));
        GridBagConstraints g = gbc();

        g.gridy = 0; p.add(lbl("Username  (min. 3 characters)"), g);
        g.gridy = 1; fldRegUser = textField(); p.add(fldRegUser, g);

        g.gridy = 2; g.insets = ins(10, 0, 4, 0); p.add(lbl("Email Address"), g);
        g.gridy = 3; g.insets = ins(0, 0, 0, 0); fldRegEmail = textField(); p.add(fldRegEmail, g);

        g.gridy = 4; g.insets = ins(10, 0, 4, 0); p.add(lbl("Password  (min. 6 characters)"), g);
        g.gridy = 5; g.insets = ins(0, 0, 0, 0);
        p.add(passwordRow(fldRegPass = pwField()), g);

        g.gridy = 6; g.insets = ins(10, 0, 4, 0); p.add(lbl("Confirm Password"), g);
        g.gridy = 7; g.insets = ins(0, 0, 0, 0);
        p.add(passwordRow(fldRegConfirm = pwField()), g);

        g.gridy = 8; g.insets = ins(4, 0, 0, 0);
        lblRegMsg = msgLabel();
        p.add(lblRegMsg, g);

        g.gridy = 9; g.insets = ins(14, 0, 0, 0);
        JButton btnReg = primaryBtn("Create Account", SUCCESS);
        btnReg.addActionListener(e -> doRegister());
        p.add(btnReg, g);

        return p;
    }

    // =========================================================================
    // İş mantığı
    // =========================================================================
    private void doLogin() {
        lblLoginMsg.setText(" ");
        String username = fldLoginUser.getText().trim();
        String password = new String(fldLoginPass.getPassword());

        if (username.isEmpty()) { setMsg(lblLoginMsg, "Username is required.", true); return; }
        if (password.isEmpty()) { setMsg(lblLoginMsg, "Password is required.", true);  return; }

        btnLogin.setEnabled(false);
        btnLogin.setText("Signing in…");

        // DB işlemi UI thread'ini bloklamaması için SwingWorker kullanılıyor
        new SwingWorker<User, Void>() {
            @Override protected User doInBackground() {
                return userService.login(username, password);
            }
            @Override protected void done() {
                btnLogin.setEnabled(true);
                btnLogin.setText("Login");
                try {
                    User user = get();
                    if (user == null) {
                        setMsg(lblLoginMsg, "Invalid username or password.", true);
                        fldLoginPass.setText("");
                        fldLoginPass.requestFocus();
                        return;
                    }
                    if ("INACTIVE".equalsIgnoreCase(user.getStatus())) {
                        setMsg(lblLoginMsg, "Your account is inactive. Contact admin.", true);
                        return;
                    }
                    // Başarılı
                    fldLoginUser.setText("");
                    fldLoginPass.setText("");
                    lblLoginMsg.setText(" ");
                    mainFrame.onLoginSuccess(user);
                } catch (Exception ex) {
                    setMsg(lblLoginMsg, "Database connection error.", true);
                }
            }
        }.execute();
    }

    private void doRegister() {
        lblRegMsg.setText(" ");
        String username = fldRegUser.getText().trim();
        String email    = fldRegEmail.getText().trim();
        String pass     = new String(fldRegPass.getPassword());
        String confirm  = new String(fldRegConfirm.getPassword());

        // Validasyon zinciri
        if (username.isEmpty())      { setMsg(lblRegMsg, "Username is required.", true); return; }
        if (username.length() < 3)   { setMsg(lblRegMsg, "Username must be at least 3 characters.", true); return; }
        if (email.isEmpty())         { setMsg(lblRegMsg, "Email is required.", true); return; }
        if (!isValidEmail(email))    { setMsg(lblRegMsg, "Enter a valid email address.", true); return; }
        if (pass.length() < 6)       { setMsg(lblRegMsg, "Password must be at least 6 characters.", true); return; }
        if (!pass.equals(confirm))   { setMsg(lblRegMsg, "Passwords do not match.", true); return; }

        boolean ok = userService.register(username, pass, email);
        if (ok) {
            setMsg(lblRegMsg, "Account created! You can now log in.", false);
            fldRegUser.setText("");
            fldRegEmail.setText("");
            fldRegPass.setText("");
            fldRegConfirm.setText("");
        } else {
            setMsg(lblRegMsg, "Registration failed. Username or email may already exist.", true);
        }
    }

    // =========================================================================
    // UI helpers
    // =========================================================================

    /** Şifre alanı + göster/gizle butonu */
    private JPanel passwordRow(JPasswordField pf) {
        JPanel row = new JPanel(new BorderLayout(4, 0));
        row.setOpaque(false);
        JToggleButton toggle = new JToggleButton("Show");
        toggle.setFont(new Font("Arial", Font.PLAIN, 11));
        toggle.setFocusPainted(false);
        toggle.setPreferredSize(new Dimension(56, 34));
        toggle.addActionListener(e -> {
            pf.setEchoChar(toggle.isSelected() ? (char) 0 : '•');
            toggle.setText(toggle.isSelected() ? "Hide" : "Show");
        });
        row.add(pf,     BorderLayout.CENTER);
        row.add(toggle, BorderLayout.EAST);
        return row;
    }

    private GridBagConstraints gbc() {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.fill = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0; g.insets = ins(0, 0, 4, 0);
        return g;
    }

    private Insets ins(int t, int l, int b, int r) { return new Insets(t, l, b, r); }

    private JLabel lbl(String text) {
        JLabel l = new JLabel(text);
        l.setFont(new Font("Arial", Font.BOLD, 12));
        l.setForeground(new Color(55, 60, 80));
        return l;
    }

    private JTextField textField() {
        JTextField f = new JTextField();
        f.setFont(new Font("Arial", Font.PLAIN, 13));
        f.setPreferredSize(new Dimension(360, 34));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(185, 192, 215)),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        return f;
    }

    private JPasswordField pwField() {
        JPasswordField f = new JPasswordField();
        f.setEchoChar('•');
        f.setFont(new Font("Arial", Font.PLAIN, 13));
        f.setPreferredSize(new Dimension(360, 34));
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(185, 192, 215)),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)));
        return f;
    }

    private JButton primaryBtn(String text, Color bg) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 14));
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(360, 40));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { if (b.isEnabled()) b.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }

    private JLabel msgLabel() {
        JLabel l = new JLabel(" ", SwingConstants.CENTER);
        l.setFont(new Font("Arial", Font.PLAIN, 11));
        return l;
    }

    private void setMsg(JLabel lbl, String msg, boolean isError) {
        lbl.setText(msg);
        lbl.setForeground(isError ? ERROR_C : SUCCESS);
    }

    private boolean isValidEmail(String email) {
        int at  = email.indexOf('@');
        int dot = email.lastIndexOf('.');
        return at > 0 && dot > at + 1 && dot < email.length() - 1;
    }
}
