package com.esportsclub;

import com.esportsclub.ui.MainFrame;

import javax.swing.*;

/**
 * Main — Uygulama giriş noktası.
 *
 * System Look & Feel ayarlanır, ardından MainFrame EDT üzerinde başlatılır.
 * (Kişi 3 tarafından yazılmıştır — K1'in test Main.java'sını bu dosya replace eder.)
 */
public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {}
            new MainFrame().setVisible(true);
        });
    }
}
