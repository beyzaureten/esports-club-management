package com.esportsclub.ui;

import com.esportsclub.model.User;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * MainFrame — E-Sports Club Management System ana penceresi.
 *
 * Mimari:
 *   - CardLayout ile tek pencerede tüm paneller yönetilir.
 *   - Login öncesi menü ve kısayollar tamamen devre dışıdır.
 *   - Role-based erişim: ADMIN tüm panellere erişir;
 *     MEMBER sadece Rapor panelini görebilir.
 *   - Gerçek zamanlı saat göstergesi (Timer, 1 sn aralık).
 *   - Pencere kapatma / logout işlemlerinde onay diyaloğu.
 *
 * Kullanılan Pattern: CardLayout (panel yönetimi)
 */
public class MainFrame extends JFrame {

    // ---- Panel sabitleri ----
    public static final String LOGIN_PANEL      = "LOGIN";
    public static final String TEAM_PANEL       = "TEAM";
    public static final String GAME_PANEL       = "GAME";
    public static final String TOURNAMENT_PANEL = "TOURNAMENT";
    public static final String MATCH_PANEL      = "MATCH";
    public static final String REPORT_PANEL     = "REPORT";

    // ---- Renk paleti ----
    private static final Color PRIMARY   = new Color(30, 80, 170);
    private static final Color ACCENT    = new Color(245, 248, 255);
    private static final Color BORDER_C  = new Color(200, 205, 220);

    // ---- State ----
    private User loggedInUser;

    // ---- Layout ----
    private CardLayout cardLayout;
    private JPanel     cardPanel;

    // ---- Menü öğeleri ----
    private JMenu     manageMenu;
    private JMenuItem miTeam, miGame, miTournament, miMatch, miReport, miLogout;

    // ---- Status bar ----
    private JLabel lblUser;
    private JLabel lblRole;
    private JLabel lblTime;
    private Timer  clockTimer;

    // ---- Panel referansları (refresh için) ----
    private TeamPanel       teamPanel;
    private GamePanel       gamePanel;
    private ReportPanel     reportPanel;

    // =========================================================================
    public MainFrame() {
        super("E-Sports & Gaming Club Management System  v1.0");
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        setSize(1200, 760);
        setMinimumSize(new Dimension(960, 620));
        setLocationRelativeTo(null);

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { requestExit(); }
        });

        buildMenuBar();
        buildCardPanel();
        buildStatusBar();
        startClock();

        showPanel(LOGIN_PANEL);
        setMenuEnabled(false);
    }

    // =========================================================================
    // MenuBar
    // =========================================================================
    private void buildMenuBar() {
        JMenuBar bar = new JMenuBar();
        bar.setBackground(ACCENT);
        bar.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER_C));

        // ---- Manage menu ----
        manageMenu = new JMenu("Manage");
        manageMenu.setFont(new Font("Arial", Font.BOLD, 13));
        manageMenu.setMnemonic(KeyEvent.VK_M);

        miTeam       = menuItem("Teams",       KeyEvent.VK_T, KeyEvent.VK_T);
        miGame       = menuItem("Games",       KeyEvent.VK_G, KeyEvent.VK_G);
        miTournament = menuItem("Tournaments", KeyEvent.VK_R, KeyEvent.VK_R);
        miMatch      = menuItem("Matches",     KeyEvent.VK_A, KeyEvent.VK_A);
        miReport     = menuItem("Reports & Statistics", KeyEvent.VK_P, KeyEvent.VK_P);
        miLogout     = new JMenuItem("Logout");
        miLogout.setFont(new Font("Arial", Font.PLAIN, 13));
        miLogout.setForeground(new Color(160, 40, 40));

        miTeam.addActionListener(e       -> showPanel(TEAM_PANEL));
        miGame.addActionListener(e       -> showPanel(GAME_PANEL));
        miTournament.addActionListener(e -> showPanel(TOURNAMENT_PANEL));
        miMatch.addActionListener(e      -> showPanel(MATCH_PANEL));
        miReport.addActionListener(e     -> { reportPanel.resetView(); showPanel(REPORT_PANEL); });
        miLogout.addActionListener(e     -> requestLogout());

        manageMenu.add(miTeam);
        manageMenu.add(miGame);
        manageMenu.add(miTournament);
        manageMenu.add(miMatch);
        manageMenu.addSeparator();
        manageMenu.add(miReport);
        manageMenu.addSeparator();
        manageMenu.add(miLogout);

        // ---- Help menu ----
        JMenu helpMenu = new JMenu("Help");
        helpMenu.setFont(new Font("Arial", Font.PLAIN, 13));
        JMenuItem miAbout = new JMenuItem("About");
        miAbout.addActionListener(e -> showAbout());
        helpMenu.add(miAbout);

        bar.add(manageMenu);
        bar.add(Box.createHorizontalGlue());
        bar.add(helpMenu);
        setJMenuBar(bar);
    }

    private JMenuItem menuItem(String text, int mnemonic, int ctrlKey) {
        JMenuItem item = new JMenuItem(text);
        item.setFont(new Font("Arial", Font.PLAIN, 13));
        item.setMnemonic(mnemonic);
        item.setAccelerator(KeyStroke.getKeyStroke(ctrlKey,
                java.awt.event.InputEvent.CTRL_DOWN_MASK));
        return item;
    }

    // =========================================================================
    // CardPanel
    // =========================================================================
    private void buildCardPanel() {
        cardLayout = new CardLayout();
        cardPanel  = new JPanel(cardLayout);
        cardPanel.setBackground(new Color(240, 242, 248));

        teamPanel   = new TeamPanel();
        gamePanel   = new GamePanel();
        reportPanel = new ReportPanel();

        cardPanel.add(new LoginPanel(this), LOGIN_PANEL);
        cardPanel.add(teamPanel,            TEAM_PANEL);
        cardPanel.add(gamePanel,            GAME_PANEL);
        cardPanel.add(new TournamentPanel(),TOURNAMENT_PANEL);
        cardPanel.add(new MatchPanel(),     MATCH_PANEL);
        cardPanel.add(reportPanel,          REPORT_PANEL);

        add(cardPanel, BorderLayout.CENTER);
    }

    // =========================================================================
    // Status Bar
    // =========================================================================
    private void buildStatusBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(new Color(248, 249, 252));
        bar.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(1, 0, 0, 0, BORDER_C),
                new EmptyBorder(3, 12, 3, 12)
        ));

        // Sol
        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        left.setOpaque(false);

        JLabel appLabel = new JLabel("E-Sports Club Management");
        appLabel.setFont(new Font("Arial", Font.BOLD, 11));
        appLabel.setForeground(PRIMARY);

        JSeparator sep1 = new JSeparator(JSeparator.VERTICAL);
        sep1.setPreferredSize(new Dimension(1, 14));

        lblUser = new JLabel("Not logged in");
        lblUser.setFont(new Font("Arial", Font.PLAIN, 11));

        lblRole = new JLabel("");
        lblRole.setFont(new Font("Arial", Font.BOLD, 11));

        left.add(appLabel);
        left.add(sep1);
        left.add(lblUser);
        left.add(lblRole);

        // Sağ: saat
        lblTime = new JLabel();
        lblTime.setFont(new Font("Arial", Font.PLAIN, 11));
        lblTime.setForeground(new Color(110, 115, 130));

        bar.add(left,    BorderLayout.WEST);
        bar.add(lblTime, BorderLayout.EAST);

        add(bar, BorderLayout.SOUTH);
    }

    private void startClock() {
        clockTimer = new Timer(1000, e ->
                lblTime.setText(LocalDateTime.now()
                        .format(DateTimeFormatter.ofPattern("dd MMM yyyy   HH:mm:ss")) + "   "));
        clockTimer.start();
    }

    // =========================================================================
    // Public API — LoginPanel ve diğer paneller tarafından çağrılır
    // =========================================================================

    /**
     * Login başarılı olduğunda LoginPanel bu metodu çağırır.
     * Rolüne göre menü öğeleri etkinleştirilir / devre dışı bırakılır.
     */
    public void onLoginSuccess(User user) {
        this.loggedInUser = user;
        boolean isAdmin = "ADMIN".equalsIgnoreCase(user.getRole());

        setMenuEnabled(true);
        miTeam.setEnabled(isAdmin);
        miGame.setEnabled(isAdmin);
        miTournament.setEnabled(isAdmin);
        miMatch.setEnabled(isAdmin);
        miReport.setEnabled(true);

        lblUser.setText("  " + user.getUsername() + "  ");
        lblRole.setText("[" + user.getRole() + "]");
        lblRole.setForeground(isAdmin ? new Color(170, 40, 40) : new Color(30, 130, 60));

        showPanel(isAdmin ? TEAM_PANEL : REPORT_PANEL);
    }

    /** Herhangi bir panel tarafından çağrılabilir. */
    public void showPanel(String name) {
        cardLayout.show(cardPanel, name);
    }

    public User getLoggedInUser() {
        return loggedInUser;
    }

    // =========================================================================
    // Private helpers
    // =========================================================================
    private void setMenuEnabled(boolean on) {
        manageMenu.setEnabled(on);
    }

    private void requestLogout() {
        int r = JOptionPane.showConfirmDialog(this,
                "You will be logged out. Continue?",
                "Logout", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r != JOptionPane.YES_OPTION) return;

        loggedInUser = null;
        lblUser.setText("Not logged in");
        lblRole.setText("");
        setMenuEnabled(false);
        showPanel(LOGIN_PANEL);
    }

    private void requestExit() {
        int r = JOptionPane.showConfirmDialog(this,
                "Exit the application?",
                "Confirm Exit", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
        if (r != JOptionPane.YES_OPTION) return;
        if (clockTimer != null) clockTimer.stop();
        dispose();
        System.exit(0);
    }

    private void showAbout() {
        JOptionPane.showMessageDialog(this,
                "E-Sports & Gaming Club Management System\n" +
                "Version 1.0  |  Spring 2026\n" +
                "MISY1102 Advanced Java for Information Management\n\n" +
                "Architecture: Model → DAO → Service → UI (Swing)\n" +
                "Database: MySQL + JDBC\n" +
                "Patterns: Singleton, Factory, Builder",
                "About", JOptionPane.INFORMATION_MESSAGE);
    }

    // =========================================================================
    // Entry point
    // =========================================================================
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try { UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName()); }
            catch (Exception ignored) {}
            new MainFrame().setVisible(true);
        });
    }
}
