package com.esportsclub.ui;

import com.esportsclub.model.Match;
import com.esportsclub.model.Team;
import com.esportsclub.model.Tournament;
import com.esportsclub.model.User;
import com.esportsclub.service.ReportManager;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

/**
 * ReportPanel — İstatistik ve rapor ekranı.
 *
 * Özellikler:
 *   - 5 özet kartı: toplam maç, aktif kullanıcı, bitmiş turnuva,
 *     en popüler takım, en çok kazanan takım
 *   - Sekmeli detay görünümleri:
 *       • Matches by Team: takım ID ile sorgu
 *       • Active Users: tüm aktif kullanıcılar
 *       • Finished Tournaments: bitmiş turnuvalar
 *   - "Load / Refresh All" butonu ile tüm veriler tek seferde çekilir
 *   - Ekran görüntüsü almaya uygun temiz tasarım (Rapor Bölüm 5 için)
 */
public class ReportPanel extends JPanel {

    private static final Color PRIMARY = new Color(30, 80, 170);

    private final ReportManager reportManager = new ReportManager();

    // ---- Özet kartları ----
    private JLabel cardMatchCount;
    private JLabel cardUserCount;
    private JLabel cardTournCount;
    private JLabel cardPopTeam;
    private JLabel cardWinTeam;

    // ---- Sekmeler ----
    private DefaultTableModel matchByTeamModel;
    private DefaultTableModel activeUserModel;
    private DefaultTableModel finishedTournModel;
    private JTextField        fldTeamIdQuery;

    // =========================================================================
    public ReportPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(new Color(240, 242, 248));
        add(buildTopBar(), BorderLayout.NORTH);
        add(buildTabs(),   BorderLayout.CENTER);
    }

    // =========================================================================
    // Toolbar
    // =========================================================================
    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBackground(new Color(240, 242, 248));
        bar.setBorder(new EmptyBorder(10, 14, 8, 14));

        JLabel title = new JLabel("Reports & Statistics");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(PRIMARY);
        bar.add(title, BorderLayout.WEST);

        JButton btnLoad = actionBtn("Load / Refresh All", PRIMARY, 160);
        btnLoad.addActionListener(e -> loadAll());
        bar.add(btnLoad, BorderLayout.EAST);

        return bar;
    }

    // =========================================================================
    // Sekmeler
    // =========================================================================
    private JPanel buildTabs() {
        JPanel wrap = new JPanel(new BorderLayout(0, 10));
        wrap.setOpaque(false);
        wrap.setBorder(new EmptyBorder(0, 14, 14, 14));

        // Özet kartları
        wrap.add(buildCards(), BorderLayout.NORTH);

        // Detay sekmeleri
        JTabbedPane tabs = new JTabbedPane();
        tabs.setFont(new Font("Arial", Font.PLAIN, 13));
        tabs.setBorder(null);
        tabs.addTab("  Matches by Team  ",    buildMatchByTeamTab());
        tabs.addTab("  Active Users  ",        buildActiveUserTab());
        tabs.addTab("  Finished Tournaments  ", buildTournamentTab());
        wrap.add(tabs, BorderLayout.CENTER);

        return wrap;
    }

    // ---- 5 istatistik kartı ----
    private JPanel buildCards() {
        JPanel row = new JPanel(new GridLayout(1, 5, 12, 0));
        row.setOpaque(false);
        row.setBorder(new EmptyBorder(0, 0, 10, 0));

        cardMatchCount = new JLabel("—", SwingConstants.CENTER);
        cardUserCount  = new JLabel("—", SwingConstants.CENTER);
        cardTournCount = new JLabel("—", SwingConstants.CENTER);
        cardPopTeam    = new JLabel("—", SwingConstants.CENTER);
        cardWinTeam    = new JLabel("—", SwingConstants.CENTER);

        row.add(statCard("Total Matches",        cardMatchCount, new Color(30,  80, 170)));
        row.add(statCard("Active Users",          cardUserCount,  new Color(34, 130,  60)));
        row.add(statCard("Finished Tournaments",  cardTournCount, new Color(155,  80,  20)));
        row.add(statCard("Most Popular Team",     cardPopTeam,    new Color(120,  50, 165)));
        row.add(statCard("Most Winning Team",     cardWinTeam,    new Color(185,  40,  40)));

        return row;
    }

    private JPanel statCard(String label, JLabel valueLabel, Color accent) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                new EmptyBorder(14, 14, 14, 14)
        ));

        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Arial", Font.PLAIN, 11));
        lbl.setForeground(new Color(100, 105, 125));

        valueLabel.setFont(new Font("Arial", Font.BOLD, 20));
        valueLabel.setForeground(accent);

        card.add(lbl,        BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    // ---- Matches by Team sekmesi ----
    private JPanel buildMatchByTeamTab() {
        JPanel p = new JPanel(new BorderLayout(0, 8));
        p.setBackground(new Color(247, 248, 252));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        JPanel queryRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        queryRow.setOpaque(false);
        queryRow.add(new JLabel("Team ID:"));
        fldTeamIdQuery = new JTextField(8);
        fldTeamIdQuery.setFont(new Font("Arial", Font.PLAIN, 13));
        queryRow.add(fldTeamIdQuery);

        JButton btnSearch = actionBtn("Search Matches", PRIMARY, 140);
        btnSearch.addActionListener(e -> loadMatchesByTeam());
        fldTeamIdQuery.addActionListener(e -> loadMatchesByTeam());
        queryRow.add(btnSearch);
        p.add(queryRow, BorderLayout.NORTH);

        String[] cols = {"Match ID", "Tournament", "Team 1", "Team 2", "Winner", "Score", "Date", "Status"};
        matchByTeamModel = readOnlyModel(cols);
        JTable tbl = styledTable(matchByTeamModel);
        p.add(new JScrollPane(tbl), BorderLayout.CENTER);
        return p;
    }

    // ---- Active Users sekmesi ----
    private JPanel buildActiveUserTab() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(247, 248, 252));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[] cols = {"ID", "Username", "Email", "Role", "Status"};
        activeUserModel = readOnlyModel(cols);
        JTable tbl = styledTable(activeUserModel);

        // Role renk
        tbl.getColumnModel().getColumn(3).setCellRenderer(new javax.swing.table.DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                if (!sel) setForeground("ADMIN".equals(v)
                        ? new Color(185, 40, 40) : new Color(30, 130, 50));
                return this;
            }
        });

        p.add(new JScrollPane(tbl), BorderLayout.CENTER);
        return p;
    }

    // ---- Finished Tournaments sekmesi ----
    private JPanel buildTournamentTab() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(new Color(247, 248, 252));
        p.setBorder(new EmptyBorder(10, 10, 10, 10));

        String[] cols = {"ID", "Tournament Name", "Game ID", "Max Teams", "Start Date", "End Date", "Status"};
        finishedTournModel = readOnlyModel(cols);
        JTable tbl = styledTable(finishedTournModel);
        p.add(new JScrollPane(tbl), BorderLayout.CENTER);
        return p;
    }

    // =========================================================================
    // Veri yükleme
    // =========================================================================
    private void loadAll() {
        // ---- Kartlar ----
        cardMatchCount.setText(String.valueOf(reportManager.getTotalMatchCount()));

        List<User> activeUsers = reportManager.getActiveUsers();
        cardUserCount.setText(String.valueOf(activeUsers.size()));

        List<Tournament> finished = reportManager.getFinishedTournaments();
        cardTournCount.setText(String.valueOf(finished.size()));

        Team pop = reportManager.getMostPopularTeam();
        cardPopTeam.setText(pop != null ? pop.getName() : "N/A");

        Team win = reportManager.getMostWinningTeam();
        cardWinTeam.setText(win != null ? win.getName() : "N/A");

        // ---- Active Users tablosu ----
        activeUserModel.setRowCount(0);
        for (User u : activeUsers)
            activeUserModel.addRow(new Object[]{
                    u.getId(), u.getUsername(), u.getEmail(), u.getRole(), u.getStatus()});

        // ---- Finished Tournaments tablosu ----
        finishedTournModel.setRowCount(0);
        for (Tournament t : finished)
            finishedTournModel.addRow(new Object[]{
                    t.getId(), t.getName(), t.getGameId(), t.getMaxTeams(),
                    t.getStartDate(), t.getEndDate(), t.getStatus()});
    }

    private void loadMatchesByTeam() {
        String idText = fldTeamIdQuery.getText().trim();
        if (idText.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a Team ID.", "Warning", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            int teamId = Integer.parseInt(idText);
            List<Match> matches = reportManager.getMatchesByTeam(teamId);
            matchByTeamModel.setRowCount(0);
            for (Match m : matches)
                matchByTeamModel.addRow(new Object[]{
                        m.getId(), m.getTournamentId(),
                        m.getTeam1Id(), m.getTeam2Id(),
                        m.getWinnerId() == 0 ? "—" : m.getWinnerId(),
                        m.getTeam1Score() + " : " + m.getTeam2Score(),
                        m.getMatchDate(), m.getStatus()});
            if (matches.isEmpty())
                JOptionPane.showMessageDialog(this,
                        "No matches found for Team ID " + teamId + ".",
                        "No Results", JOptionPane.INFORMATION_MESSAGE);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Invalid Team ID.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** ReportPanel'i sıfırla — başka panelden buraya geçildiğinde çağrılır */
    public void resetView() {
        // Kartlar zaten yüklendiyse istatistikleri yenile
        loadAll();
    }

    // =========================================================================
    // UI helpers
    // =========================================================================
    private DefaultTableModel readOnlyModel(String[] cols) {
        return new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
    }

    private JTable styledTable(DefaultTableModel m) {
        JTable t = new JTable(m);
        t.setFont(new Font("Arial", Font.PLAIN, 12));
        t.setRowHeight(24);
        t.setGridColor(new Color(218, 220, 232));
        t.setShowHorizontalLines(true);
        t.setShowVerticalLines(false);
        t.setSelectionBackground(new Color(195, 215, 255));
        t.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        t.getTableHeader().setBackground(new Color(230, 235, 250));
        t.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        return t;
    }

    private JButton actionBtn(String text, Color bg, int width) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 12));
        b.setBackground(bg); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(width, 30));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }
}
