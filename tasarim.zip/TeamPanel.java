package com.esportsclub.ui;

import com.esportsclub.dao.TeamMemberDAO;
import com.esportsclub.factory.TeamBuilder;
import com.esportsclub.factory.TeamFactory;
import com.esportsclub.model.Game;
import com.esportsclub.model.Team;
import com.esportsclub.model.TeamMember;
import com.esportsclub.service.GameService;
import com.esportsclub.service.TeamService;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.List;

/**
 * TeamPanel — Takım yönetimi (CRUD) ekranı.
 *
 * Özellikler:
 *   - TeamBuilder (Builder Pattern): form değerlerinden adım adım Team nesnesi oluşturma
 *   - TeamFactory (Factory Pattern): "Quick Add" ile COMPETITIVE / CASUAL / TRAINING şablonları
 *   - JSplitPane: üst tablo + alt üye listesi, yeniden boyutlandırılabilir
 *   - Kapasite sütunu: "2 / 5" formatında mevcut/max gösterimi
 *   - Status renk kodlaması: ACTIVE → yeşil, INACTIVE → kırmızı
 *   - Canlı arama, status filtresi, game filtresi
 *   - Silmeden önce kapasite uyarısı (üye varsa bilgilendirme)
 */
public class TeamPanel extends JPanel {

    // ---- Renkler ----
    private static final Color PRIMARY   = new Color(30, 80, 170);
    private static final Color BTN_ADD   = new Color(34, 130, 60);
    private static final Color BTN_UPD   = new Color(30, 80, 170);
    private static final Color BTN_DEL   = new Color(185, 40, 40);
    private static final Color BTN_CLR   = new Color(100, 105, 120);
    private static final Color BTN_QICK  = new Color(130, 60, 175);

    private final TeamService   teamService   = new TeamService();
    private final GameService   gameService   = new GameService();
    private final TeamMemberDAO memberDAO     = new TeamMemberDAO();

    // ---- Ana tablo ----
    private JTable            teamTable;
    private DefaultTableModel teamModel;
    private TableRowSorter<DefaultTableModel> sorter;

    // ---- Alt: üye listesi ----
    private JTable            memberTable;
    private DefaultTableModel memberModel;
    private JLabel            lblMemberTitle;

    // ---- Filtre ----
    private JTextField    fldSearch;
    private JComboBox<String> cmbStatus;
    private JComboBox<String> cmbGameFilter;

    // ---- Form ----
    private JTextField    fldId, fldName;
    private JComboBox<String> cmbGame;
    private JSpinner      spnCapacity;
    private JComboBox<String> cmbStatusForm;
    private JComboBox<String> cmbQuickType;

    // ---- Durum ----
    private JLabel lblCount;

    // =========================================================================
    public TeamPanel() {
        setLayout(new BorderLayout(0, 0));
        setBackground(new Color(240, 242, 248));
        add(buildToolbar(), BorderLayout.NORTH);
        add(buildSplit(),   BorderLayout.CENTER);
        add(buildForm(),    BorderLayout.SOUTH);
        loadAll();
    }

    // =========================================================================
    // Toolbar
    // =========================================================================
    private JPanel buildToolbar() {
        JPanel bar = new JPanel(new BorderLayout(10, 0));
        bar.setBackground(new Color(240, 242, 248));
        bar.setBorder(new EmptyBorder(10, 14, 8, 14));

        JLabel title = new JLabel("Team Management");
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setForeground(PRIMARY);
        bar.add(title, BorderLayout.WEST);

        JPanel filters = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        filters.setOpaque(false);

        filters.add(sLbl("Search:"));
        fldSearch = new JTextField(14);
        fldSearch.setFont(new Font("Arial", Font.PLAIN, 12));
        fldSearch.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e) { applyFilter(); }
            public void removeUpdate(DocumentEvent e) { applyFilter(); }
            public void changedUpdate(DocumentEvent e) {}
        });
        filters.add(fldSearch);

        filters.add(sLbl("Status:"));
        cmbStatus = new JComboBox<>(new String[]{"All", "ACTIVE", "INACTIVE"});
        cmbStatus.setPreferredSize(new Dimension(95, 26));
        cmbStatus.addActionListener(e -> applyFilter());
        filters.add(cmbStatus);

        filters.add(sLbl("Game:"));
        cmbGameFilter = new JComboBox<>();
        cmbGameFilter.setPreferredSize(new Dimension(130, 26));
        cmbGameFilter.addActionListener(e -> applyFilter());
        filters.add(cmbGameFilter);

        JButton btnRefresh = aBtn("Refresh", new Color(90, 95, 110), 75);
        btnRefresh.addActionListener(e -> loadAll());
        filters.add(btnRefresh);

        bar.add(filters, BorderLayout.EAST);
        return bar;
    }

    // =========================================================================
    // SplitPane: üst tablo + alt üye listesi
    // =========================================================================
    private JSplitPane buildSplit() {
        JSplitPane sp = new JSplitPane(JSplitPane.VERTICAL_SPLIT,
                buildTeamTable(), buildMemberPanel());
        sp.setResizeWeight(0.62);
        sp.setDividerSize(5);
        sp.setBorder(null);
        return sp;
    }

    private JScrollPane buildTeamTable() {
        String[] cols = {"ID", "Team Name", "Game", "Members / Max", "Status"};
        teamModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
            @Override public Class<?> getColumnClass(int c) {
                return c == 0 ? Integer.class : String.class;
            }
        };

        teamTable = new JTable(teamModel);
        teamTable.setFont(new Font("Arial", Font.PLAIN, 13));
        teamTable.setRowHeight(27);
        teamTable.setGridColor(new Color(218, 220, 232));
        teamTable.setShowHorizontalLines(true);
        teamTable.setShowVerticalLines(false);
        teamTable.setSelectionBackground(new Color(195, 215, 255));
        teamTable.setSelectionForeground(Color.BLACK);
        teamTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        teamTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 13));
        teamTable.getTableHeader().setBackground(new Color(230, 235, 250));
        teamTable.getTableHeader().setReorderingAllowed(false);

        int[] widths = {55, 220, 170, 130, 95};
        for (int i = 0; i < widths.length; i++)
            teamTable.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);

        // ID ve kapasite ortala
        DefaultTableCellRenderer center = new DefaultTableCellRenderer();
        center.setHorizontalAlignment(SwingConstants.CENTER);
        teamTable.getColumnModel().getColumn(0).setCellRenderer(center);
        teamTable.getColumnModel().getColumn(3).setCellRenderer(center);

        // Status renk
        teamTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override public Component getTableCellRendererComponent(
                    JTable t, Object v, boolean sel, boolean foc, int r, int c) {
                super.getTableCellRendererComponent(t, v, sel, foc, r, c);
                setHorizontalAlignment(CENTER);
                if (!sel) setForeground("ACTIVE".equals(v)
                        ? new Color(30, 130, 50) : new Color(185, 40, 40));
                return this;
            }
        });

        sorter = new TableRowSorter<>(teamModel);
        teamTable.setRowSorter(sorter);

        teamTable.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) { fillForm(); loadMembers(); }
        });

        JScrollPane sp = new JScrollPane(teamTable);
        sp.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(205, 210, 225)));
        return sp;
    }

    private JPanel buildMemberPanel() {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(new Color(247, 248, 252));
        p.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(205, 210, 225)));

        lblMemberTitle = new JLabel("  Team Members  —  select a team to view members");
        lblMemberTitle.setFont(new Font("Arial", Font.BOLD, 12));
        lblMemberTitle.setForeground(new Color(75, 80, 105));
        lblMemberTitle.setBorder(new EmptyBorder(6, 8, 4, 0));
        p.add(lblMemberTitle, BorderLayout.NORTH);

        String[] cols = {"Member ID", "Team ID", "User ID", "Join Date"};
        memberModel = new DefaultTableModel(cols, 0) {
            @Override public boolean isCellEditable(int r, int c) { return false; }
        };
        memberTable = new JTable(memberModel);
        memberTable.setFont(new Font("Arial", Font.PLAIN, 12));
        memberTable.setRowHeight(23);
        memberTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        memberTable.getTableHeader().setBackground(new Color(235, 238, 250));

        p.add(new JScrollPane(memberTable), BorderLayout.CENTER);
        return p;
    }

    // =========================================================================
    // Form
    // =========================================================================
    private JPanel buildForm() {
        JPanel wrap = new JPanel(new BorderLayout(0, 0));
        wrap.setBackground(new Color(247, 248, 252));
        wrap.setBorder(BorderFactory.createMatteBorder(1, 0, 0, 0, new Color(205, 210, 225)));

        JPanel form = new JPanel(new GridBagLayout());
        form.setOpaque(false);
        form.setBorder(new EmptyBorder(10, 14, 6, 14));
        GridBagConstraints g = new GridBagConstraints();
        g.fill = GridBagConstraints.HORIZONTAL;
        g.insets = new Insets(4, 6, 4, 6);

        // Satır 1
        g.gridy = 0;
        g.gridx = 0; g.weightx = 0.05; form.add(fLbl("ID"), g);
        g.gridx = 1; g.weightx = 0.1;
        fldId = new JTextField(); fldId.setEditable(false);
        fldId.setBackground(new Color(228, 230, 240));
        fldId.setFont(new Font("Arial", Font.PLAIN, 12));
        form.add(fldId, g);

        g.gridx = 2; g.weightx = 0.09; form.add(fLbl("Team Name *"), g);
        g.gridx = 3; g.weightx = 0.3; fldName = formField("e.g. Team Phoenix"); form.add(fldName, g);

        g.gridx = 4; g.weightx = 0.08; form.add(fLbl("Game *"), g);
        g.gridx = 5; g.weightx = 0.2;
        cmbGame = new JComboBox<>(); cmbGame.setFont(new Font("Arial", Font.PLAIN, 12));
        form.add(cmbGame, g);

        // Satır 2
        g.gridy = 1;
        g.gridx = 0; g.weightx = 0.05; form.add(fLbl("Max Cap. *"), g);
        g.gridx = 1; g.weightx = 0.1;
        spnCapacity = new JSpinner(new SpinnerNumberModel(5, 1, 50, 1));
        spnCapacity.setFont(new Font("Arial", Font.PLAIN, 12));
        form.add(spnCapacity, g);

        g.gridx = 2; g.weightx = 0.09; form.add(fLbl("Status"), g);
        g.gridx = 3; g.weightx = 0.3;
        cmbStatusForm = new JComboBox<>(new String[]{"ACTIVE", "INACTIVE"});
        cmbStatusForm.setFont(new Font("Arial", Font.PLAIN, 12));
        form.add(cmbStatusForm, g);

        g.gridx = 4; g.weightx = 0.08;
        JLabel qLabel = fLbl("Quick Type");
        qLabel.setToolTipText("Uses TeamFactory — auto-fills capacity");
        form.add(qLabel, g);
        g.gridx = 5; g.weightx = 0.2;
        cmbQuickType = new JComboBox<>(new String[]{
                "COMPETITIVE  (cap=5)", "CASUAL  (cap=10)", "TRAINING  (cap=3)"});
        cmbQuickType.setFont(new Font("Arial", Font.PLAIN, 12));
        cmbQuickType.setToolTipText("Uses TeamFactory.createTeam() — Quick Add button");
        form.add(cmbQuickType, g);

        wrap.add(form, BorderLayout.CENTER);

        // ---- Butonlar ----
        JPanel btnRow = new JPanel(new BorderLayout(0, 0));
        btnRow.setOpaque(false);
        btnRow.setBorder(new EmptyBorder(0, 14, 10, 14));

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        left.setOpaque(false);

        JButton btnAdd      = aBtn("Add Team",   BTN_ADD,  110);
        JButton btnUpdate   = aBtn("Update",     BTN_UPD,  90);
        JButton btnDelete   = aBtn("Delete",     BTN_DEL,  90);
        JButton btnClear    = aBtn("Clear Form", BTN_CLR,  95);
        JButton btnQuickAdd = aBtn("Quick Add",  BTN_QICK, 95);
        btnQuickAdd.setToolTipText("Creates team using TeamFactory with selected Quick Type");

        btnAdd.addActionListener(e      -> doAdd());
        btnUpdate.addActionListener(e   -> doUpdate());
        btnDelete.addActionListener(e   -> doDelete());
        btnClear.addActionListener(e    -> clearForm());
        btnQuickAdd.addActionListener(e -> doQuickAdd());

        left.add(btnAdd); left.add(btnUpdate); left.add(btnDelete); left.add(btnClear);
        left.add(new JSeparator(JSeparator.VERTICAL) {{ setPreferredSize(new Dimension(1, 24)); }});
        left.add(btnQuickAdd);

        lblCount = new JLabel();
        lblCount.setFont(new Font("Arial", Font.ITALIC, 11));
        lblCount.setForeground(new Color(115, 120, 140));

        btnRow.add(left,     BorderLayout.WEST);
        btnRow.add(lblCount, BorderLayout.EAST);
        wrap.add(btnRow, BorderLayout.SOUTH);

        return wrap;
    }

    // =========================================================================
    // İş mantığı
    // =========================================================================

    /** Builder Pattern: formdaki değerlerden TeamBuilder ile Team oluşturur */
    private void doAdd() {
        String name = fldName.getText().trim();
        if (name.isEmpty()) { warn("Team name is required."); return; }
        Object gameItem = cmbGame.getSelectedItem();
        if (gameItem == null) { warn("Please select a game."); return; }
        int gameId = parseGameId(gameItem.toString());
        if (gameId < 0) { error("Selected game not found."); return; }

        // Builder Pattern
        Team team = new TeamBuilder()
                .setName(name)
                .setGameId(gameId)
                .setMaxCapacity((int) spnCapacity.getValue())
                .setStatus(cmbStatusForm.getSelectedItem().toString())
                .build();

        if (team == null) { error("Invalid team data (TeamBuilder returned null)."); return; }

        if (teamService.addTeam(team)) {
            info("Team \"" + name + "\" added (via TeamBuilder).");
            clearForm(); loadAll();
        } else { error("Failed to add team."); }
    }

    /** Factory Pattern: TeamFactory şablonuyla hızlı takım oluşturur */
    private void doQuickAdd() {
        String name = fldName.getText().trim();
        if (name.isEmpty()) { warn("Enter a team name first, then click Quick Add."); return; }
        Object gameItem = cmbGame.getSelectedItem();
        if (gameItem == null) { warn("Please select a game."); return; }
        int gameId = parseGameId(gameItem.toString());
        if (gameId < 0) { error("Selected game not found."); return; }

        // Factory Pattern
        String typeStr = cmbQuickType.getSelectedItem().toString().split(" ")[0]; // "COMPETITIVE"
        Team team = TeamFactory.createTeam(typeStr, name, gameId);

        if (teamService.addTeam(team)) {
            info("Team \"" + name + "\" added as " + typeStr + " (via TeamFactory).");
            clearForm(); loadAll();
        } else { error("Failed to add team."); }
    }

    private void doUpdate() {
        if (fldId.getText().trim().isEmpty()) { warn("Select a team from the table first."); return; }
        String name = fldName.getText().trim();
        if (name.isEmpty()) { warn("Team name is required."); return; }
        Object gameItem = cmbGame.getSelectedItem();
        int gameId = gameItem != null ? parseGameId(gameItem.toString()) : -1;
        if (gameId < 0) { warn("Please select a game."); return; }

        try {
            Team t = new Team(Integer.parseInt(fldId.getText().trim()), name, gameId,
                    (int) spnCapacity.getValue(),
                    cmbStatusForm.getSelectedItem().toString());
            if (teamService.updateTeam(t)) { info("Team updated."); clearForm(); loadAll(); }
        } catch (NumberFormatException ex) { error("Invalid ID."); }
    }

    private void doDelete() {
        if (fldId.getText().trim().isEmpty()) { warn("Select a team first."); return; }
        try {
            int id   = Integer.parseInt(fldId.getText().trim());
            boolean hasMem = teamService.isTeamFull(id)
                    || memberDAO.countByTeamId(id) > 0;
            String extra = hasMem ? "\n\nWarning: this team has members — they will not be deleted." : "";
            int r = JOptionPane.showConfirmDialog(this,
                    "Delete team \"" + fldName.getText().trim() + "\"?" + extra,
                    "Confirm Delete", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (r != JOptionPane.YES_OPTION) return;
            teamService.deleteTeam(id);
            info("Team deleted."); clearForm(); loadAll();
        } catch (NumberFormatException ex) { error("Invalid ID."); }
    }

    // =========================================================================
    // Veri yükleme / filtreleme
    // =========================================================================
    private void loadAll() {
        teamModel.setRowCount(0);
        List<Team> teams = teamService.getAllTeams();
        List<Game> games = gameService.getAllGames();

        for (Team t : teams) {
            String gameName = games.stream()
                    .filter(g -> g.getId() == t.getGameId())
                    .map(Game::getName).findFirst()
                    .orElse("Unknown (" + t.getGameId() + ")");
            int cur = memberDAO.countByTeamId(t.getId());
            teamModel.addRow(new Object[]{
                    t.getId(), t.getName(), gameName,
                    cur + " / " + t.getMaxCapacity(), t.getStatus()
            });
        }

        // Game filter
        Object curGF = cmbGameFilter.getSelectedItem();
        cmbGameFilter.removeAllItems();
        cmbGameFilter.addItem("All Games");
        games.stream().map(Game::getName).sorted().forEach(cmbGameFilter::addItem);
        if (curGF != null) cmbGameFilter.setSelectedItem(curGF);

        // Form game combo
        Object curGC = cmbGame.getSelectedItem();
        cmbGame.removeAllItems();
        games.forEach(g -> cmbGame.addItem(g.getName() + "  [id=" + g.getId() + "]"));
        if (curGC != null) cmbGame.setSelectedItem(curGC);

        updateCount();
    }

    private void applyFilter() {
        String kw      = fldSearch.getText().trim();
        String status  = cmbStatus.getSelectedItem().toString();
        Object gf      = cmbGameFilter.getSelectedItem();
        String game    = (gf == null || "All Games".equals(gf)) ? "" : gf.toString();

        sorter.setRowFilter(RowFilter.andFilter(Arrays.asList(
                kw.isEmpty()     ? RowFilter.regexFilter(".*")
                                 : RowFilter.regexFilter("(?i)" + kw, 1, 2),
                "All".equals(status) ? RowFilter.regexFilter(".*")
                                     : RowFilter.regexFilter("^" + status + "$", 4),
                game.isEmpty()   ? RowFilter.regexFilter(".*")
                                 : RowFilter.regexFilter("(?i)" + game, 2)
        )));
        updateCount();
    }

    private void loadMembers() {
        memberModel.setRowCount(0);
        if (fldId.getText().trim().isEmpty()) {
            lblMemberTitle.setText("  Team Members  —  select a team to view members");
            return;
        }
        try {
            int id = Integer.parseInt(fldId.getText().trim());
            List<TeamMember> members = memberDAO.getByTeamId(id);
            lblMemberTitle.setText("  Members of \"" + fldName.getText().trim()
                    + "\"  (" + members.size() + " member" + (members.size() != 1 ? "s" : "") + ")");
            for (TeamMember m : members)
                memberModel.addRow(new Object[]{m.getId(), m.getTeamId(), m.getUserId(), m.getJoinDate()});
        } catch (NumberFormatException ignored) {}
    }

    private void fillForm() {
        int row = teamTable.getSelectedRow();
        if (row < 0) return;
        int mr = teamTable.convertRowIndexToModel(row);
        fldId.setText(teamModel.getValueAt(mr, 0).toString());
        fldName.setText(teamModel.getValueAt(mr, 1).toString());

        // Game combo seçimi
        String gName = teamModel.getValueAt(mr, 2).toString();
        for (int i = 0; i < cmbGame.getItemCount(); i++) {
            if (cmbGame.getItemAt(i).startsWith(gName)) { cmbGame.setSelectedIndex(i); break; }
        }
        // Kapasite
        String capStr = teamModel.getValueAt(mr, 3).toString().split("/")[1].trim();
        try { spnCapacity.setValue(Integer.parseInt(capStr)); } catch (Exception ignored) {}
        cmbStatusForm.setSelectedItem(teamModel.getValueAt(mr, 4).toString());
    }

    private void clearForm() {
        fldId.setText(""); fldName.setText("");
        if (cmbGame.getItemCount() > 0) cmbGame.setSelectedIndex(0);
        spnCapacity.setValue(5);
        cmbStatusForm.setSelectedIndex(0);
        teamTable.clearSelection();
        memberModel.setRowCount(0);
        lblMemberTitle.setText("  Team Members  —  select a team to view members");
        fldName.requestFocus();
    }

    private int parseGameId(String item) {
        try { return Integer.parseInt(item.replaceAll(".*\\[id=(\\d+)\\].*", "$1")); }
        catch (Exception e) { return -1; }
    }

    private void updateCount() {
        lblCount.setText("Showing " + teamTable.getRowCount()
                + " of " + teamModel.getRowCount() + " teams   ");
    }

    // =========================================================================
    // UI helpers
    // =========================================================================
    private JLabel fLbl(String t) {
        JLabel l = new JLabel(t); l.setFont(new Font("Arial", Font.BOLD, 12));
        l.setForeground(new Color(55, 60, 80)); return l;
    }
    private JLabel sLbl(String t) {
        JLabel l = new JLabel(t); l.setFont(new Font("Arial", Font.PLAIN, 12)); return l;
    }
    private JTextField formField(String tip) {
        JTextField f = new JTextField();
        f.setFont(new Font("Arial", Font.PLAIN, 12)); f.setToolTipText(tip);
        f.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(185, 192, 215)),
                BorderFactory.createEmptyBorder(3, 7, 3, 7)));
        return f;
    }
    private JButton aBtn(String text, Color bg, int w) {
        JButton b = new JButton(text);
        b.setFont(new Font("Arial", Font.BOLD, 12));
        b.setBackground(bg); b.setForeground(Color.WHITE);
        b.setFocusPainted(false); b.setBorderPainted(false);
        b.setPreferredSize(new Dimension(w, 30));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.addMouseListener(new MouseAdapter() {
            @Override public void mouseEntered(MouseEvent e) { b.setBackground(bg.darker()); }
            @Override public void mouseExited(MouseEvent e)  { b.setBackground(bg); }
        });
        return b;
    }
    private void info(String m)  { JOptionPane.showMessageDialog(this, m, "Success", JOptionPane.INFORMATION_MESSAGE); }
    private void warn(String m)  { JOptionPane.showMessageDialog(this, m, "Warning", JOptionPane.WARNING_MESSAGE); }
    private void error(String m) { JOptionPane.showMessageDialog(this, m, "Error",   JOptionPane.ERROR_MESSAGE); }
}
