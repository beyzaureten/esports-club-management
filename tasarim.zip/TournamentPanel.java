package com.esportsclub.ui;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;

/**
 * TournamentPanel — Turnuva yönetimi paneli.
 *
 * Bu sınıf Kişi 3 tarafından oluşturulmuş yapısal placeholder'dır.
 * Kişi 1 (TournamentService, TournamentDAO) ve Kişi 3 birlikte
 * tam CRUD + bracket görünümünü H6 haftasında tamamlayacaktır.
 *
 * Planlanan özellikler:
 *   - Turnuva CRUD (oluştur, düzenle, sil)
 *   - Takım kayıt / çıkarma (TournamentTeamDAO)
 *   - Bracket görünümü (JPanel + Graphics2D)
 *   - Status geçişleri: UPCOMING → ONGOING → FINISHED
 */
public class TournamentPanel extends JPanel {

    public TournamentPanel() {
        setLayout(new BorderLayout());
        setBackground(new Color(240, 242, 248));

        JPanel center = new JPanel(new GridBagLayout());
        center.setOpaque(false);
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.insets = new Insets(0, 0, 12, 0);

        JLabel icon = new JLabel("🏆", SwingConstants.CENTER);
        icon.setFont(new Font("Arial", Font.PLAIN, 52));
        g.gridy = 0; center.add(icon, g);

        JLabel msg = new JLabel("Tournament Management", SwingConstants.CENTER);
        msg.setFont(new Font("Arial", Font.BOLD, 22));
        msg.setForeground(new Color(30, 80, 170));
        g.gridy = 1; center.add(msg, g);

        JLabel sub = new JLabel("Full implementation: Kişi 1 + Kişi 3  —  H6 Sprint",
                SwingConstants.CENTER);
        sub.setFont(new Font("Arial", Font.PLAIN, 13));
        sub.setForeground(new Color(110, 115, 135));
        g.gridy = 2; center.add(sub, g);

        add(center, BorderLayout.CENTER);
    }
}
